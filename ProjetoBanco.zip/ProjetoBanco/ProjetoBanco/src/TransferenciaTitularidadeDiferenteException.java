
public class TransferenciaTitularidadeDiferenteException  extends Exception{

	public TransferenciaTitularidadeDiferenteException(String message) {
		super(message);
}
}
