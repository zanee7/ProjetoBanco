
public class ContaCorrente {

	public class ContaCorrente extends Conta{

		public ContaCorrente(int numero) {
			super(numero);
		}

		private double tarifa;
	}

}
