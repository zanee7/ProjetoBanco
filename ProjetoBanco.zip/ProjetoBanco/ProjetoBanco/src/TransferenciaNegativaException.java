
public class TransferenciaNegativaException extends RuntimeException {

	public TransferenciaNegativaException(String message) {
		super(message);
		
}
}
