
public class SaqueContaPoupancaException {
	
	
	public SaqueContaPoupancaException(String message) {
		super(message);
}
}
