
public class SaqueMaiorException extends RuntimeException {


	public SaqueMaiorException(String message) {
		super(message);
	}
}
