

public class Conta {

		public int numero;
		public double saldo;
		
		
		public Conta(int numero) {
			super(); 
			this.numero = numero;
		}
		
		public void depositar(double valor) {
			saldo += valor;
		}


		public int getNumero() {
			return numero;
		}


		public double getSaldo() {
			return saldo;
		}
		
		
	}


