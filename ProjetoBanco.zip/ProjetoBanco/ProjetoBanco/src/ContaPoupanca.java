
public class ContaPoupanca {

	public ContaPoupanca(int numero) {
		super(numero);
	}

	private double taxa;
}


