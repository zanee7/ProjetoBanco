
public class SaquePoupancaException extends RuntimeException{
	
	public SaquePoupancaException(String message) {
		super(message);
}
}
