import javax.management.loading.PrivateClassLoader;

public class App {

	public static void main(String[] args) {
		App app = new App();
		
		
		ContaPoupanca contaPoupanca = new ContaPoupanca(1234);
		ContaCorrente contaCorrente = new ContaCorrente(5678);
		
		try {
			app.init();
		} catch (RuntimeException e) {
			System.err.println("Um erro aconteceu: " + e.getMessage());
		}
		
		contaPoupanca.saldo = 9;
		contaCorrente.saldo = 10;
		
		private void saqueContaCorrente() throws SaqueMaiorException
		if (saqueContaCorrente > contaCorrente)
			throw new = Exception("Saque maior que o disponível");
		
		
		private void saqueContaPoupanca() throws SaqueContaPoupancaException
		if (saqueContaPoupanca < 0)
			throw new = Exception("Saque em conta poupança");
		
		private void deposito() throws DepositoNegativoException
		if (deposito < 0)
			throw new = Exception("Deposito negativo")
			
		private void transferirConta() throws TransferenciaTitularidadeDiferenteException
		if (titularidade2 != titularidade1)
			throw new = Exception ("Titularidades diferentes")
			
		contaPoupanca.depositar(10);
		contaCorrente.depositar(15);
		System.out.println(contaCorrente.getSaldo());
		
	}

}
